//
//  ViewController.swift
//  Final Exam
//
//  Created by Jeson Rosario on 12/13/19.
//  Copyright © 2019 Jeson Rosario. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    lazy var game = Game()
    private var deck = PlayingCardDeck()
    private var cardViews = [PlayingCardView]()
    
    var cashCount = 100 {
        didSet{
            cashLabel.text = "$: \(cashCount)"
            betLabel.text = "Bet: $\(game.betAmount)"
            
            if(game.cashAmount <= 0){

            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        updateCards()

    }

    @IBOutlet var playerHand: [PlayingCardView]!
    
    @IBOutlet var computerHand: [PlayingCardView]!
    
    lazy var animator = UIDynamicAnimator(referenceView: self.view)
    
    @IBAction func dealButton(_ sender: UIButton) {
        if( game.betAmount > 0){
            //do animation
            flipCard()
        }
    }
    
    @IBAction func betButton(_ sender: UIButton) {
        cashCount = game.substractCash()
    }
    
    @IBAction func resetButton(_ sender: UIButton) {
        game.reset()
        deck = PlayingCardDeck()
        cashLabel.text = "$: \(game.cashAmount)"
        betLabel.text = "Bet: $\(game.betAmount)"
        updateCards()
    }
    
    @IBOutlet weak var cashLabel: UILabel!
    @IBOutlet weak var betLabel: UILabel!
    
//    private func createAnimation(_ cardView : PlayingCardView, Count i: Double){
//        for cardView in playerCards {
//            let duration = 0.5
//            UIView.transition(
//                with: cardView,
//                duration: 1.0,
//                options: [.transitionFlipFromLeft],
//                animations: {
//                    cardView.backgroundColor = #colorLiteral(red: 0.6253926829, green: 0.7058015416, blue: 1, alpha: 1)
//            },
//                completion:{finished in
//                    UIView.transition(
//                        with: cardView,
//                        duration: duration*i,
//                        options: [.transitionFlipFromLeft],
//                        animations:
//                        {cardView.isFaceUp = !cardView.isFaceUp},
//                        completion: nil)})
//        }
//    }
    
    func updateCards(){
        
        var cards = [PlayingCard]()
        
        for _ in 1...((computerHand.count)){
            let card = deck.draw()!
            cards += [card]
        }
        
        for cardView in computerHand{
            cardView.isFaceUp = false
            let card = cards.remove(at:cards.count.arc4random)
            cardView.rank = card.rank.order
            cardView.suit = card.suit.rawValue
        }
        
        for _ in 1...((playerHand.count)){
            let card = deck.draw()!
            cards += [card]
        }
        for cardView in playerHand{
            cardView.isFaceUp = false
            let card = cards.remove(at:cards.count.arc4random)
            cardView.rank = card.rank.order
            cardView.suit = card.suit.rawValue
            //cardView.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(flipCard(_:))))
        }    }
    
    
    func flipCard(){
        for cardView in playerHand{
            UIView.transition(with: cardView,
                              duration: 0.5,
                              options: [.transitionFlipFromLeft],
                              animations: {cardView.isFaceUp = !cardView.isFaceUp}
            )
            
        }
        for cpucardView in computerHand{
            UIView.transition(with: cpucardView, duration: 0.5, options: [.transitionFlipFromLeft], animations: {cpucardView.isFaceUp = !cpucardView.isFaceUp}
            )
        }
        
    }
    
    
    
    
}

