//
//  ViewController.swift
//  Final Exam
//
//  Created by Jeson Rosario on 12/13/19.
//  Copyright © 2019 Jeson Rosario. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    //TODO: Missing Requirement 9
    //TODO: Swipe Gesture

    lazy var game = Game()
    private var deck = PlayingCardDeck()
    private var cardViews = [PlayingCardView]()
    
    var cashCount = 100 {
        didSet{
            cashLabel.text = "$: \(cashCount)"
            betLabel.text = "Bet: $\(game.betAmount)"
            
            if(game.cashAmount <= 0){

            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        updateCards()

    }

    @IBOutlet var playerHand: [PlayingCardView]!
    
    @IBOutlet var computerHand: [PlayingCardView]!
    
    lazy var animator = UIDynamicAnimator(referenceView: self.view)
    
    @IBAction func dealButton(_ sender: UIButton) {
        if( game.betAmount > 0){
            if didClick == true {
                didClick = false
                deck = PlayingCardDeck()
                playerLabel.text = "Player Score: 0"
                computerLabel.text = "CPU Score: 0"
            } else {
                didClick = true
                game.compareSums()
                cashLabel.text = "$: \(game.cashAmount)"
                betLabel.text = "Bet: $\(game.betAmount)"
                playerLabel.text = "Player Score: \(game.playerSum)"
                computerLabel.text = "CPU Score: \(game.computerSum)"
                game.computerSum = 0
                game.playerSum = 0
                deck = PlayingCardDeck()
                updateCards()
            }
            flipCard()
        }

    }
    
    @IBAction func betButton(_ sender: UIButton) {
        cashCount = game.substractCash()
    }
    
    @IBAction func resetButton(_ sender: UIButton) {
        game.reset()
        deck = PlayingCardDeck()
        didClick = false
        updateCards()
        cashLabel.text = "$: \(game.cashAmount)"
        betLabel.text = "Bet: $\(game.betAmount)"
        playerLabel.text = "Player Score: 0"
        computerLabel.text = "CPU Score: 0"
        
    }
    
    @IBOutlet weak var cashLabel: UILabel!
    @IBOutlet weak var betLabel: UILabel!
    
    @IBOutlet weak var playerLabel: UILabel!
    @IBOutlet weak var computerLabel: UILabel!
    
    func updateCards(){
        
        var cards = [PlayingCard]()
        
        for _ in 1...((playerHand.count)) {
            let card = deck.draw()!
            cards += [card]
        }
        
        for cardView in playerHand {
            cardView.isFaceUp = false
            let card = cards.remove(at:cards.count.arc4random)
            let cardRank = PlayingCard.rankNumber()
            cardView.rank = cardRank
            cardView.suit = card.suit.rawValue
            game.checkPlayerCards(rank: cardRank, suit: cardView.suit)
        }
        
        for _ in 1...((computerHand.count)) {
            let card = deck.draw()!
            cards += [card]
        }
        
        for cardView in computerHand {
            cardView.isFaceUp = false
            let card = cards.remove(at:cards.count.arc4random)
            let cardRank = PlayingCard.rankNumber()
            cardView.rank = cardRank
            cardView.suit = card.suit.rawValue
            game.checkCompCards(rank: cardRank, suit: cardView.suit)
        }
        if didClick == false {
            playerLabel.text = "Player Score: 0"
            computerLabel.text = "CPU Score: 0"
        } else {
            game.compareSums()
            cashLabel.text = "$: \(game.cashAmount)"
            betLabel.text = "Bet: $\(game.betAmount)"
            playerLabel.text = "Player Score: \(game.playerSum)"
            computerLabel.text = "CPU Score: \(game.computerSum)"
            
        }
        
        
    }
    
    var didClick = false
    var cards = [PlayingCard]()
    
    func flipCard(){
        for cardView in playerHand{
            UIView.transition(with: cardView,
                              duration: 0.5,
                              options: [.transitionFlipFromLeft],
                              animations: {cardView.isFaceUp = !cardView.isFaceUp}
            )
            if cardView.isFaceUp == false {
                // Will set bet amount to 0 after bet is placed
                game.betAmount = 0
                betLabel.text = "Bet: $\(game.betAmount)"
            }
        }
        
        for cpucardView in computerHand{
            UIView.transition(with: cpucardView, duration: 0.5, options: [.transitionFlipFromLeft], animations: {cpucardView.isFaceUp = !cpucardView.isFaceUp}
            )
        }
        
    }
    
    
    
    
    
}

