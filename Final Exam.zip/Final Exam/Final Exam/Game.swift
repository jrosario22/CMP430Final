//
//  Game.swift
//  Final Exam
//
//  Created by Jeson Rosario on 12/15/19.
//  Copyright © 2019 Jeson Rosario. All rights reserved.
//

import Foundation

class Game {
    
    var deck = PlayingCardDeck()
    
    var playerCards = [PlayingCard]()
    var computerCards = [PlayingCard]()
    
    var cashAmount = 100
    var betAmount = 0

    var playerSum = 0
    var computerSum = 0
    

    
    func checkPlayerCards(rank: Int, suit: String) {
        if (rank == 1){
            playerSum += 14
        } else {
            playerSum += rank
        }
        switch suit {
        case "♠️":
            playerSum += 4
            print("4 was added")
        
        case "❤️":
            playerSum += 3
            print("3 was added")
            
        case "♦️":
            playerSum += 2
            print("2 was added")
            
        case "♣️":
            playerSum += 1
            print("1 was added")
        
        default:
            return
        }
        print("The player sum is \(playerSum)")
    }
    
    func checkCompCards(rank: Int, suit: String) {
        if (rank == 1){
            computerSum += 14
        } else {
            computerSum += rank
        }
        switch suit {
        case "♠️":
            computerSum += 4
            print("4 was added")
            
        case "❤️":
            computerSum += 3
            print("3 was added")
            
        case "♦️":
            computerSum += 2
            print("2 was added")
            
        case "♣️":
            computerSum += 1
            print("1 was added")
            
        default:
            return
        }
        print("The computer sum is \(computerSum)")
    }
    
    func compareSums() {
        if playerSum >= 2 * computerSum {
            cashAmount += 4 * betAmount
        } else if playerSum > computerSum {
            cashAmount += 2 * betAmount
        }
        
        if playerSum == computerSum {
            cashAmount += betAmount
        }
        
    }
    
    func substractCash() -> Int {
        if(cashAmount > 0) {
            cashAmount -= 1
            betAmount += 1
        }
        
        return cashAmount
        
    }
    
    func reset() {
        cashAmount = 100
        betAmount = 0
        playerSum = 0
        computerSum = 0
    }
    
    
    

}
