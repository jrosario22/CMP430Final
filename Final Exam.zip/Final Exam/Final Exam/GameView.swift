//
//  GameView.swift
//  Final Exam
//
//  Created by Jeson Rosario on 12/15/19.
//  Copyright © 2019 Jeson Rosario. All rights reserved.
//

import UIKit

class GameView: UIView {

    private var gameStart = false
    public var lastIndex = 0
    override func layoutSubviews() {
        super .layoutSubviews()
        
        let setGrid = Grid(for: self.frame,
                           withNoOfFrames: self.subviews.count,
                           forIdeal: 5.0)
        var i = 1
        for index in self.subviews.indices {
//            if (self.subviews.count == 5 || lastIndex == 83){
//                lastIndex = 0
//            }
            
            if var frame = setGrid[index] {
                let duration = 0.4
                frame.size.width -= 5
                frame.size.height -= 5
                if index > lastIndex{
                    lastIndex = index
                    UIViewPropertyAnimator.runningPropertyAnimator(
                        withDuration: duration,
                        delay: duration * Double(i),
                        options: [],
                        animations: {
                            self.subviews[index].frame = frame
                    },
                        completion: nil)
                    i+=1
                }else{
                    UIViewPropertyAnimator.runningPropertyAnimator(
                        withDuration: duration,
                        delay: 0,
                        options: [],
                        animations: {
                            self.subviews[index].frame = frame
                            
                    },
                        completion: nil)
                }
            }
        }
    }

}
